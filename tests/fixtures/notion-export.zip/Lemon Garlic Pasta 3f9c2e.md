# Lemon Garlic Pasta

Serves 2 · Prep 10 min · Cook 15 min

## Ingredients

- 200 g spaghetti
- 2 tbsp butter
- 3 cloves garlic, finely chopped
- 1 lemon, zested and juiced
- ½ cup grated parmesan

## Method

1. Cook the spaghetti in plenty of salted boiling water until it is just tender, about ten minutes.
2. Melt the butter in a pan and fry the garlic for a minute.
3. Toss the pasta with the butter, lemon and parmesan, and serve straight away.
